<?php
    $host = "localhost";
    $db_u = "root";
    $db_p = "";
    $db_n = "przychodnia";
?>