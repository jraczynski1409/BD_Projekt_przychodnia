folder ratmedik zawiera interfejs graficzny. Można go skompilować w xamppie.
plik przychodnia.sql zawiera baze danych przepisaną do jezyka mysql.