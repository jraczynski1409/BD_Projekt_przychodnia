/*--------------TABELE-------------*/

drop table cnb;
drop table badania;
drop table choroby;
drop table leki_na_recepcie;
drop table recepty;
drop table leki;
drop table pracownicy;
drop table stanowiska;
drop table pacjenci;
drop table osoby;
drop table przychodnie;
drop table adresy;