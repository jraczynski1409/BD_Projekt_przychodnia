/*--------------------------1.ADRESY------------------------*/

INSERT INTO Adresy VALUES (1,'Równa','12a','32','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (2,'Wspólna','15','1','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (3,'Złota','25','11','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (4,'Śniadeckich','22/24','10','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (5,'Paderewskiego','11','48','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (6,'Olszewskiego','3b','12','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (7,'Nowaka-Jeziorańskiego','55','30','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (8,'Nowaka-Jeziorańskiego','55','29','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (9,'Grunwaldzka','5','3','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (10,'Jagielońska','41','8','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (11,'Szajnowicza-Iwanowa','13a','22','Kielce','25-001','Świetokrzyskie');
INSERT INTO Adresy VALUES (12,'Niestachów','100',NULL,'Daleszyce','26-021','Świetokrzyskie');
INSERT INTO Adresy VALUES (13,'Niestachów','188',NULL,'Daleszyce','26-021','Świetokrzyskie');
INSERT INTO Adresy VALUES (14,'Wola Jachowa','100',NULL,'Górno','26-008','Świetokrzyskie');
INSERT INTO Adresy VALUES (15,'Przemysłowa','100',NULL,'Przysucha','26-400','Mazowieckie');

/*---------------2.PPRZYCHODNIE----------------*/

INSERT INTO Przychodnie VALUES (1,'Przychodnia Ratmedik w Kielcach nr.1','681793455',5);
INSERT INTO Przychodnie VALUES (2,'Przychodnia Ratmedik w Niestachowie','681793456',13);
INSERT INTO Przychodnie VALUES (3,'SOR Ratmedik','681793998',9);


/*---------------3.OSOBY----------------*/

INSERT INTO Osoby VALUES (1, 'Jakub', 'Raczynski','M','888137582','jakubraczynski@gmail.com','99325489633',to_date('14/09/2000','DD/MM/YYYY'),12,'kuba','mocnehaslo');
INSERT INTO Osoby VALUES (2, 'Robert', 'Kaleta','M','245758222','robertkaleta@gmail.com','99359764821',to_date('13/12/2000','DD/MM/YYYY'),14,'robson','mocnniejszehaslo');
INSERT INTO Osoby VALUES (3, 'Bartłomiej', 'Palus','M','968247361','bartlomiejpalus@gmail.com','95637845214',to_date('21/10/2000','DD/MM/YYYY'),15,'bartek','najmocnniejszehaslo');
INSERT INTO Osoby VALUES (4, 'Krzysztof', 'Krawczyk','M','786428392','parostatek@wrejs.com','55978641385',to_date('14/12/1955','DD/MM/YYYY'),1,'krawczyk','stateknapare');
INSERT INTO Osoby VALUES (5, 'Maryla', 'Rodowicz','K','758963214','mlodaja@podajtlen.com','11015699987',to_date('02/04/1911','DD/MM/YYYY'),11,'wieczniemloda','kolorowejarmarki');
INSERT INTO Osoby VALUES (6, 'Krzysztof', 'Ibisz','M','789632541','ibisz@poltas.com','12889557487',to_date('30/07/1912','DD/MM/YYYY'),2,'ibisz','botox123');
INSERT INTO Osoby VALUES (7, 'Maria', 'Skłodowska','K','129875641','rad@rad.com','88669452473',to_date('07/11/1988','DD/MM/YYYY'),10,'maria','ur@dowana1');
INSERT INTO Osoby VALUES (8, 'Bolesław', 'Chrobry','M','976348615','kocham@drewno.com','12397684521',to_date('10/02/1954','DD/MM/YYYY'),7,'bolek','mieszko');
INSERT INTO Osoby VALUES (9, 'Kazimierz', 'Wielki','M','752465789','kocham@mury.com','76814129763',to_date('28/03/1928','DD/MM/YYYY'),8,'murbeton','piedziesiatzlotych');
INSERT INTO Osoby VALUES (10, 'Janina', 'Nowak','K','793684256','chytra@baba.com','78954128876',to_date('10/08/1992','DD/MM/YYYY'),4,'janinkack','brajanek');
INSERT INTO Osoby VALUES (11, 'Brajan', 'Nowak','M','188246875','brajanek@gmail.com','18187898788',to_date('01/09/2018','DD/MM/YYYY'),4,'brajannowak','piec100dodac');
INSERT INTO Osoby VALUES (12, 'Jessika', 'Nowak','K','188246866','dzesikan@gmail.com','18187898777',to_date('01/09/2018','DD/MM/YYYY'),4,'jlonowak','piec100dodacrazy2');
INSERT INTO Osoby VALUES (13, 'Witold', 'Kowalski','M','889768852','wk@gmail.com','79684523879',to_date('01/01/1978','DD/MM/YYYY'),6,'witek12','mariola');
INSERT INTO Osoby VALUES (14, 'Mariola', 'Kowalska','K','889768853','mk@gmail.com','78469381752',to_date('16/05/1978','DD/MM/YYYY'),5,'mariola69','witold');
INSERT INTO Osoby VALUES (15, 'Hanna', 'Mostowiak','K','789684253','hannam@carton.com','70897878652',to_date('16/09/1970','DD/MM/YYYY'),3,'hannka','mareczek');



/*---------------4.PACJENCI----------------*/

INSERT INTO pacjenci VALUES (1,(SELECT sysdate - round(dbms_random.value(10,20)) as "data" from dual),'T',1);
INSERT INTO pacjenci VALUES (2,(SELECT sysdate - round(dbms_random.value(10,20)) as "data" from dual),'T',2);
INSERT INTO pacjenci VALUES (3,(SELECT sysdate - round(dbms_random.value(10,20)) as "data" from dual),'T',3);
INSERT INTO pacjenci VALUES (4,(SELECT sysdate - round(dbms_random.value(11,15)) as "data" from dual),'T',4);
INSERT INTO pacjenci VALUES (5,(SELECT sysdate - round(dbms_random.value(11,15)) as "data" from dual),'T',5);
INSERT INTO pacjenci VALUES (6,(SELECT sysdate - round(dbms_random.value(16,18)) as "data" from dual),'T',6);
INSERT INTO pacjenci VALUES (7,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'N',7);
INSERT INTO pacjenci VALUES (8,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',8);
INSERT INTO pacjenci VALUES (9,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',9);
INSERT INTO pacjenci VALUES (10,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',10);
INSERT INTO pacjenci VALUES (11,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'N',11);
INSERT INTO pacjenci VALUES (12,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',12);
INSERT INTO pacjenci VALUES (13,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',13);
INSERT INTO pacjenci VALUES (14,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'N',14);
INSERT INTO pacjenci VALUES (15,(SELECT sysdate - round(dbms_random.value(1,10)) as "data" from dual),'T',15);


/*---------------5.Stanowisko----------------*/

INSERT INTO stanowiska VALUES (1, 'Pediatra', 'Lekarz zajmujący się leczeniem dzieci.');
INSERT INTO stanowiska VALUES (2, 'Pielegniarka', 'Osoba asystująca lekarzą. Wykonuje takie obowiązki jak pobranie krwi i tym podobne.');
INSERT INTO stanowiska VALUES (3, 'Chirurg', 'Lekarz który wykonuje oprecaje i zabegi na niemal wszystkich elementach ciała człowieka.');
INSERT INTO stanowiska VALUES (4, 'Dermatolog', 'Lekarz zajmujący się chorobami skóry.');
INSERT INTO stanowiska VALUES (5, 'Endokrynolog', 'Lekarz zajmujący się chorobami tarczycy.');
INSERT INTO stanowiska VALUES (6, 'Kardiolog', 'Lekarz zajmujący się chorobami serca.');
INSERT INTO stanowiska VALUES (7, 'Lekarz medycyny pracy', 'Lekarz zajmujący się podbijaniem ksiązeczki xD.');
INSERT INTO stanowiska VALUES (8, 'Neurolog', 'Lekarz zajmujący się chorobami kręgosłupa oraz układu nerwowego.');
INSERT INTO stanowiska VALUES (9, 'Okulista', 'Lekarz zajmujący się chorobami oczu.');
INSERT INTO stanowiska VALUES (10, 'Stomatolog', 'Lekarz badający uzębienie lub jego brak xD.');
INSERT INTO stanowiska VALUES (11, 'Psychiatra', 'Lekarz zajmujący się chorobami psychicznymi.');
INSERT INTO stanowiska VALUES (12, 'Laboratorant', 'Osoba badająca różne próbki które zostały zlecone przez lekarza.');
INSERT INTO stanowiska VALUES (13, 'Ginekolog', 'Osoba badająca brzuszek i to co sie w nim znajduje.');
INSERT INTO stanowiska VALUES (14, 'Dietetyk', 'Układanie diet i porady żywieniowe');
INSERT INTO stanowiska VALUES (15, 'Ortopeda', 'Lekarz zajmujący sie patologiami układu kostnego.');


/*---------------6.PRACOWNICY----------------*/

INSERT INTO pracownicy values (1, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 5300, 3, 1, 1);
INSERT INTO pracownicy values (2, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 3100, 2, 2, 2);
INSERT INTO pracownicy values (3, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 4500, 1, 3, 3);
INSERT INTO pracownicy values (4, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 5600, 6, 4, 1);
INSERT INTO pracownicy values (5, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 5600, 5, 5, 2);
INSERT INTO pracownicy values (6, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 3900, 4, 6, 3);
INSERT INTO pracownicy values (7, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 5800, 8, 7, 1);
INSERT INTO pracownicy values (8, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 4000, 7, 8, 2);
INSERT INTO pracownicy values (9, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 3900, 9, 9, 3);
INSERT INTO pracownicy values (10, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 4600, 15, 10, 3);
INSERT INTO pracownicy values (11, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 6000, 13, 11, 1);
INSERT INTO pracownicy values (12, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 3300, 12, 12, 2);
INSERT INTO pracownicy values (13, (SELECT sysdate - round(dbms_random.value(20,25)) as "data" from dual), (SELECT sysdate + round(dbms_random.value(50,100)) as "data" from dual) , 4900, 10, 15, 3);


/*---------------7.Leki----------------*/

INSERT INTO leki values (1, 'Rutinoscorbin', 10.59);
INSERT INTO leki values (2, 'Ascorlamid', 20.99);
INSERT INTO leki values (3, 'Witamina C 1000', 15.99);
INSERT INTO leki values (4, 'BabyBoom', 9.99);
INSERT INTO leki values (5, 'Vigantoletten 1000', 20.99);
INSERT INTO leki values (6, 'Ketonal', 25.89);
INSERT INTO leki values (7, 'Theraflu', 18.99);
INSERT INTO leki values (8, 'Amol', 32.99);
INSERT INTO leki values (9, 'Apap', 21.99);
INSERT INTO leki values (10, 'Multilac', 18.59);
INSERT INTO leki values (11, 'Xylometazolin', 7.99);
INSERT INTO leki values (12, 'Otrivin', 20.49);
INSERT INTO leki values (13, 'Nasic', 16.49);
INSERT INTO leki values (14, 'Allegra', 11.59);
INSERT INTO leki values (15, 'Sudafet', 17.89);


/*---------------8.Recepty----------------*/

INSERT INTO recepty values (1, 'fawe23tser4w3dsafg4q', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (2, 'gshyku75232341rdfa32', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (3, 'gasfcqw343wasfceas3r', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (4, '4gfdh6usdf3asdfg342g', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (5, 'asd3fzve3qwdzfzdfwe2', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (6, 'gsdf3qwdasdzwd2qad3a', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (7, 'fawed2qgsdf3f54fsdfe', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (8, 'fbw4aw43rvw3avefaw3r', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (9, 'vaw3rvdefaw3rvvadefr', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (10, 'vaw3rvasefzawrwarfwa', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (11, 'avw3rvasdfwrfwefawvr', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (12, 'tvuyd5tvawerffsafwdf', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (13, 'asdfvawervwsdfgrvhdn', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (14, 'vaw23ts5ytvse4va32r2', 'T', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));
INSERT INTO recepty values (15, '123rsafwr23revsdrt3w', 'N', (SELECT sysdate + round(dbms_random.value(30,60)) as "data" from dual));



/*---------------9.Leki_na_RECEPCIE----------------*/

INSERT INTO leki_na_recepcie values (1, 1,1,25);
INSERT INTO leki_na_recepcie values (2, 1,3,25);
INSERT INTO leki_na_recepcie values (3, 2,5,90);
INSERT INTO leki_na_recepcie values (4, 3,4,0);
INSERT INTO leki_na_recepcie values (5, 4,8,0);
INSERT INTO leki_na_recepcie values (6, 4,2,0);
INSERT INTO leki_na_recepcie values (7, 5,3,100);
INSERT INTO leki_na_recepcie values (8, 5,5,50);
INSERT INTO leki_na_recepcie values (9, 7,11,80);
INSERT INTO leki_na_recepcie values (10, 9,15,0);
INSERT INTO leki_na_recepcie values (11, 12,1,0);
INSERT INTO leki_na_recepcie values (12, 12,15,25);
INSERT INTO leki_na_recepcie values (13, 14,2,20);
INSERT INTO leki_na_recepcie values (14, 15,4,100);
INSERT INTO leki_na_recepcie values (15, 15,8,0);


/*---------------10.Choroby----------------*/

Insert into choroby values (1,'Przeziebienie', 'Wirusowa', 'kaszel, katar');
Insert into choroby values (2,'Grypa', 'Wirusowa', 'Gorączka, kaszel, złe samopoczucie, ból mięśniowo-szkieletowy');
Insert into choroby values (3,'Covid-19', 'Wirusowa', 'Gorączka, kaszel, katar, brak wechu i smaku');
Insert into choroby values (4,'Ospa wietrzna', 'Wirusowa', 'krosty na całym ciele');
Insert into choroby values (5,'Świnka', 'Wirusowa', 'Powiekszenie slinianek przyusznych');
Insert into choroby values (6,'Różyczka', 'Wirusowa', 'Wysypka, powiekszenie wezlów chłonnych');
Insert into choroby values (7,'Cukrzyca', 'Metaboliczna', 'Nietolerancja cukru');
Insert into choroby values (8,'Zapalenie płuc', 'Wirusowa', 'Infekcja płuc');
Insert into choroby values (9,'Arytmia', 'Zaburzenia', 'Nie regularne bicie serca');
Insert into choroby values (10,'Nadczynność tarczycy', 'Metaboliczna', 'Ciagłe zapalenie tarczycy');
Insert into choroby values (11,'Zapalenie ucha', 'Bakteryjne', 'Silny ból ucha');
Insert into choroby values (12,'Zapalenie zatok', 'Bakteryjna', 'Silny katar i ucisk w zatokach');
Insert into choroby values (13,'Złamana kończyna', 'Uraz', 'Złamanie kończyny');
Insert into choroby values (14,'Kamienie nerkowe', 'Metaboliczna', 'Kolka nerwowa');
Insert into choroby values (15,'Trądzik', 'Bakteryjna', 'Krosty i ropnie na skórze');


/*---------------11.BADANIA----------------*/

INSERT INTO badania values (1,0,'Wizyta kontrolna. Kaszel i wymioty',11,3,1);
INSERT INTO badania values (2,300,'Badanie krwi',9,2,2);
INSERT INTO badania values (3,150,'Badanie krwi i moczu',8,2,3);
INSERT INTO badania values (4,200,'Echo serca',10,4,4);
INSERT INTO badania values (5,0,'Badanie wzroku',6,9,5);
INSERT INTO badania values (6,50,'Przeciecie ropnia',8,1,6);
INSERT INTO badania values (7,500,'Rezonans',5,7,7);
INSERT INTO badania values (8,25,'Badanie krwi i moczu',7,2,8);
INSERT INTO badania values (9,100,'Badanie kału',15,2,9);
INSERT INTO badania values (10,40,'Wizyta u dermatologa',14,6,10);
INSERT INTO badania values (11,89,'Wizyta kontrolna',8,3,11);
INSERT INTO badania values (12,100,'Badanie serca',9,4,12);
INSERT INTO badania values (13,0,'Badanie próbek',2,12,13);
INSERT INTO badania values (14,0,'Leczenie zebów',3,12,14);
INSERT INTO badania values (15,250,'Wyrywanie zeba nr.1',1,12,15);

/*---------------12.CHOROBY_NA_BADANIU----------------*/

insert into cnb values (1,1,5);
insert into cnb values (2,1,3);
insert into cnb values (3,3,3);
insert into cnb values (4,4,4);
insert into cnb values (5,5,3);
insert into cnb values (6,5,1);
insert into cnb values (7,7,3);
insert into cnb values (8,8,3);
insert into cnb values (9,8,5);
insert into cnb values (10,8,2);
insert into cnb values (11,11,3);
insert into cnb values (12,11,3);
insert into cnb values (13,14,6);
insert into cnb values (14,14,8);
insert into cnb values (15,15,7);