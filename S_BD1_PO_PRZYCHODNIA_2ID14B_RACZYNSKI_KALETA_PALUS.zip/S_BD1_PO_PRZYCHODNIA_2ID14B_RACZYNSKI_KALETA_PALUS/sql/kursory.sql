--------------------------------------------------KURSORY------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------PODWYZKA----------------
CREATE OR REPLACE PROCEDURE podwyzka (procent numeric, pracownik numeric)
IS
CURSOR cur_pod IS
	select id_pracownika,koniec_umowy,pensja from pracownicy where id_pracownika=pracownik;
    
pen numeric := 0;
tmp cur_pod%rowtype;
begin 
open cur_pod;
    Fetch cur_pod INTO tmp;
    pen := tmp.pensja;
    Update pracownicy set pracownicy.pensja=pen*((100+procent)/100) where id_pracownika=tmp.id_pracownika;
    
close cur_pod;
end;
/


-----------PREMIA---------------------

CREATE OR REPLACE PROCEDURE premia (pre numeric, pracownik numeric)
IS
CURSOR cur_pre IS
	select id_pracownika,koniec_umowy,pensja from pracownicy where id_pracownika=pracownik;
    
tmp cur_pre%rowtype;
begin 
open cur_pre;
    Fetch cur_pre INTO tmp;
    Update pracownicy set pracownicy.pensja=pracownicy.pensja+pre where id_pracownika=tmp.id_pracownika;
    
close cur_pre;
end;
/

------------PRZEDŁURZENIE---UMOWY-------------
create or replace procedure przedluzanie_umowy (dldni date, idprac numeric) is
cursor cur_pu is
    select id_pracownika,koniec_umowy from pracownicy where id_pracownika=idprac;

tmp cur_pu%rowtype;

begin 
open cur_pu;
    fetch cur_pu into tmp;
    update pracownicy set pracownicy.koniec_umowy=dldni where pracownicy.id_pracownika=tmp.id_pracownika;
close cur_pu;
end;
/

------------ZMIANA_CENY_LEKU--------------------
CREATE OR REPLACE PROCEDURE zw_cene_leku (nowacena numeric, idlek numeric)
IS
CURSOR cur_zcl IS
	select * from leki where id_leku=idlek;
    
cen numeric := 0;
tmp cur_zcl%rowtype;
begin 
open cur_zcl;
    Fetch cur_zcl INTO tmp;
    cen := tmp.cena;
    Update leki set leki.cena=nowacena where id_leku=tmp.id_leku;
close cur_zcl;
end;
/
